package com.uiauto;

import java.io.FileNotFoundException;
import java.io.ObjectInputStream.GetField;

import utils.Common;
import utils.ImgCompare;
import utils.Location;
import utils.PackageEvent;
import utils.Selector;

import android.os.Bundle;
import android.os.RemoteException;

import com.android.uiautomator.core.UiObject;
import com.android.uiautomator.core.UiObjectNotFoundException;
import com.android.uiautomator.testrunner.UiAutomatorTestCase;

/**
 * 20s内判断是否来电
 * 
 * 截图对比和包名匹配的对比： 1.截图对比适用绝大多数机型，无需单独适配机型/UI。 2.包名匹配准确，可区分不可预测的界面，如收到短信引起的界面变化等。
 * 在此，所有的机器都采用截图对比
 * 
 * @author 魏亮
 */
public class AnswerPhoneCheckInCall extends UiAutomatorTestCase {
	Common common = new Common();
	PackageEvent packageEvent = new PackageEvent();

	// ImgCompare imgCompare = new ImgCompare();

	@Override
	protected void setUp() throws Exception {
		common.creatFile(getClass().getName());
		common.watcherTheError(getUiDevice(), getClass().getName());// 运行错误报告监听器
	}

	@Override
	protected void tearDown() throws Exception {

	}

	public void testDemo() throws UiObjectNotFoundException, RemoteException {
		try {
			callTwo();
		} catch (Exception e) {
			common.takeshot(getUiDevice(), getClass().getName());
			e.printStackTrace();
		} finally {
			// getUiDevice().pressHome();
		}
	}

	public void callTwo() throws Exception {
		// 红牛系列
		Bundle bundle = getParams();
		String runcount = bundle.getString("runcount");
		System.out.println("被测试的设备名称是" + getUiDevice().getProductName());
		// nubia与原生机的区别，home主页的搜索框：nubia和原生google搜索不一样，前提home页不能改变。-wl160922
		// 无视实际UI，无差别地将可能出现的的log界面尝试开启，能开就开启对应的log抓取
		getUiDevice().pressHome();
		getUiDevice().pressHome();
		UiObject searchshift = Location.resourceIdObject("com.android.launcher3:id/qsb_widget");
		if (searchshift.waitForExists(5000) || getUiDevice().getProductName().contains("551")
				|| getUiDevice().getProductName().contains("549") || getUiDevice().getProductName().contains("569")) {
			// 2016-09-21原生机&&2016-12-1黑莓BBC
			imgCompare2();
		} else {// nubia手机 Log 4.0
				// nubia系列
				// 如果20秒内没有看到来电界面，则算作失败
			for (int j = 0; j < 40; j++) {
				String CurrentPackageName = getUiDevice().getCurrentPackageName();
				if (j == 39) {
					if (!getUiDevice().isScreenOn()) {// 截图前避免熄屏
						getUiDevice().wakeUp();
					}
					common.takeshotByDate(getUiDevice(), getClass().getName(), "The_" + runcount + "_time_call_fail_");
					System.out.println("第" + runcount + "次未接到来电-" + common.getDate());
				}
				if (CurrentPackageName.contains("incall") || CurrentPackageName.contains("phone")) {
					// 20秒内来电成功
					if (!getUiDevice().isScreenOn()) {// 截图前避免熄屏
						getUiDevice().wakeUp();
					}
					common.takeshotByDate(getUiDevice(), getClass().getName(),
							"The_" + runcount + "_time_call_success_");
					System.out.println("第" + runcount + "次接到来电");
					j = 41;
				} else {
					sleep(500);
				}
			}
		}

	}

	// 2016-09-21原生机来电界面，只在上部有通知，且无法获取控件——>进行截图对比
	public void imgCompare2() throws RemoteException, UiObjectNotFoundException, FileNotFoundException {
		Bundle bundle = getParams();
		String runcount = bundle.getString("runcount");
		sleep(15000);// 25000->15000
		String picName = "The_" + runcount + "_time_call_Rate_" + common.getDate();
		common.takeshot(getUiDevice(), getClass().getName(), picName);
		sleep(500);
		if (ImgCompare.sameAs("/storage/self/primary/uiauto/CallBefore/Incall.png",
				"/storage/self/primary/uiauto/AnswerPhoneCheckInCall/" + picName + ".png", 0.80)
				|| ImgCompare.sameAs("/storage/self/primary/uiauto/CallBefore/Incallblack.png",
						"/storage/self/primary/uiauto/AnswerPhoneCheckInCall/" + picName + ".png", 0.99)) {// 桌面截图和黑屏截图两次对比确认未收到来电
			System.out.println("第" + runcount + "次未接到来电-" + common.getDate());
		} else {
			System.out.println("第" + runcount + "次接到来电");
		}

	}

}

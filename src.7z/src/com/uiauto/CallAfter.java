package com.uiauto;

import java.io.DataOutputStream;
import java.io.OutputStream;

import utils.CmdAdb;
import utils.Common;
import utils.Location;
import utils.PackageEvent;
import utils.Selector;

import android.os.RemoteException;

import com.android.uiautomator.core.UiCollection;
import com.android.uiautomator.core.UiObject;
import com.android.uiautomator.core.UiObjectNotFoundException;
import com.android.uiautomator.core.UiSelector;
import com.android.uiautomator.testrunner.UiAutomatorTestCase;

/**
 * 结束关闭log开关
 * 
 * @author 潘亚男、魏亮
 *
 */

public class CallAfter extends UiAutomatorTestCase {
	Common common = new Common();
	PackageEvent packageEvent = new PackageEvent();

	@Override
	protected void setUp() throws Exception {
		common.creatFile(getClass().getName());
		// common.unLock(getUiDevice());
		common.watcherTheError(getUiDevice(), getClass().getName());// 运行错误报告监听器
	}

	@Override
	protected void tearDown() throws Exception {
	}

	public void testDemo() throws UiObjectNotFoundException, RemoteException {
		try {
			callEnd();
		} catch (Exception e) {
			common.takeshot(getUiDevice(), getClass().getName());
			e.printStackTrace();
		} finally {
			// getUiDevice().pressHome();
		}
	}

	public void callEnd() throws Exception {
		// 使用准备条件
		System.out.println("进行测试收尾");
		// nubia UI4.0的log开关获取
		UiObject logshift4 = new UiObject(new UiSelector().resourceId("cn.nubia.woodpecker:id/action_enable"));
		UiObject startStopToggleButton = new UiObject(
				new UiSelector().resourceId("com.mediatek.mtklogger:id/startStopToggleButton"));
		// MTK项目
		common.cmdImput("am start --activity-single-top -n com.mediatek.mtklogger/com.mediatek.mtklogger.MainActivity");
		// nubia系列
		common.cmdImput("am start --activity-single-top -n cn.nubia.woodpecker/.logger.LoggerActivity");// nubia手机4.5
		sleep(500);
		//关闭log开关，为导出log做准备
		if(getUiDevice().getProductName().contains("551")||getUiDevice().getProductName().contains("569")){
			sleep(5000);
			getUiDevice().click(542, 1840);
			sleep(1000);
		}else if(getUiDevice().getProductName().contains("573")|| getUiDevice().getProductName().contains("575")){
			sleep(2000);
			startStopToggleButton.click();
			sleep(1000);
		}else{
			if (!logshift4.getContentDescription().equals("开始")) {
				logshift4.click();
			}
		}
		getUiDevice().pressHome();

	}
}
